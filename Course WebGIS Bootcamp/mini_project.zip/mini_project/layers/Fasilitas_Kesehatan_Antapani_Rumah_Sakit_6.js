var json_Fasilitas_Kesehatan_Antapani_Rumah_Sakit_6 = {
"type": "FeatureCollection",
"name": "Fasilitas_Kesehatan_Antapani_Rumah_Sakit_6",
"crs": { "type": "name", "properties": { "name": "urn:ogc:def:crs:OGC:1.3:CRS84" } },
"features": [
{ "type": "Feature", "properties": { "OID_": "0", "Name": "Hermina Arcamanik Hospital", "FolderPath": "Fasilitas Kesehatan Antapani\/Rumah Sakit", "SymbolID": "0", "AltMode": "-1", "Base": 0.0, "Snippet": null, "PopupInfo": null, "HasLabel": "-1", "LabelID": "0" }, "geometry": { "type": "Point", "coordinates": [ 107.666749, -6.904909 ] } },
{ "type": "Feature", "properties": { "OID_": "0", "Name": "RSIA Grha Bunda", "FolderPath": "Fasilitas Kesehatan Antapani\/Rumah Sakit", "SymbolID": "0", "AltMode": "-1", "Base": 0.0, "Snippet": null, "PopupInfo": null, "HasLabel": "-1", "LabelID": "0" }, "geometry": { "type": "Point", "coordinates": [ 107.645617300000083, -6.913266199999953 ] } },
{ "type": "Feature", "properties": { "OID_": "0", "Name": "Rumah Sakit Santo Yusup", "FolderPath": "Fasilitas Kesehatan Antapani\/Rumah Sakit", "SymbolID": "0", "AltMode": "-1", "Base": 0.0, "Snippet": null, "PopupInfo": null, "HasLabel": "-1", "LabelID": "0" }, "geometry": { "type": "Point", "coordinates": [ 107.643095600000038, -6.906675199999938 ] } }
]
}
