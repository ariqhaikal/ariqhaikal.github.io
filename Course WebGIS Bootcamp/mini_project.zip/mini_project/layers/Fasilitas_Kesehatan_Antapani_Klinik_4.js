var json_Fasilitas_Kesehatan_Antapani_Klinik_4 = {
"type": "FeatureCollection",
"name": "Fasilitas_Kesehatan_Antapani_Klinik_4",
"crs": { "type": "name", "properties": { "name": "urn:ogc:def:crs:OGC:1.3:CRS84" } },
"features": [
{ "type": "Feature", "properties": { "OID_": "0", "Name": "Klinik Utama Medika Antapani", "FolderPath": "Fasilitas Kesehatan Antapani\/Klinik", "SymbolID": "0", "AltMode": "-1", "Base": 0.0, "Snippet": null, "PopupInfo": null, "HasLabel": "-1", "LabelID": "0" }, "geometry": { "type": "Point", "coordinates": [ 107.652048300000047, -6.913798399999962 ] } },
{ "type": "Feature", "properties": { "OID_": "0", "Name": "Klinik Pratama Medika Antapani", "FolderPath": "Fasilitas Kesehatan Antapani\/Klinik", "SymbolID": "0", "AltMode": "-1", "Base": 0.0, "Snippet": null, "PopupInfo": null, "HasLabel": "-1", "LabelID": "0" }, "geometry": { "type": "Point", "coordinates": [ 107.651454200000046, -6.913011599999948 ] } }
]
}
