var json_Fasilitas_Kesehatan_Antapani_Puskesmas_5 = {
"type": "FeatureCollection",
"name": "Fasilitas_Kesehatan_Antapani_Puskesmas_5",
"crs": { "type": "name", "properties": { "name": "urn:ogc:def:crs:OGC:1.3:CRS84" } },
"features": [
{ "type": "Feature", "properties": { "OID_": "0", "Name": "PUSKESMAS ANTAPANI", "FolderPath": "Fasilitas Kesehatan Antapani\/Puskesmas", "SymbolID": "0", "AltMode": "-1", "Base": 0.0, "Snippet": null, "PopupInfo": null, "HasLabel": "-1", "LabelID": "0" }, "geometry": { "type": "Point", "coordinates": [ 107.663547, -6.913430399999982 ] } },
{ "type": "Feature", "properties": { "OID_": "0", "Name": "Puskesmas Griya Antapani", "FolderPath": "Fasilitas Kesehatan Antapani\/Puskesmas", "SymbolID": "0", "AltMode": "-1", "Base": 0.0, "Snippet": null, "PopupInfo": null, "HasLabel": "-1", "LabelID": "0" }, "geometry": { "type": "Point", "coordinates": [ 107.660436600000082, -6.916775 ] } },
{ "type": "Feature", "properties": { "OID_": "0", "Name": "UPT PUSKESMAS JAJAWAY", "FolderPath": "Fasilitas Kesehatan Antapani\/Puskesmas", "SymbolID": "0", "AltMode": "-1", "Base": 0.0, "Snippet": null, "PopupInfo": null, "HasLabel": "-1", "LabelID": "0" }, "geometry": { "type": "Point", "coordinates": [ 107.664213200000063, -6.927566499999955 ] } }
]
}
